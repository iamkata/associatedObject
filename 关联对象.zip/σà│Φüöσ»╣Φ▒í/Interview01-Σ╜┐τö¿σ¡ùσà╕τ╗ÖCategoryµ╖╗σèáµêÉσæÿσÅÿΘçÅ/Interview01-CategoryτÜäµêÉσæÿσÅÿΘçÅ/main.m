//
//  main.m
//  Interview01-Category的成员变量
//
//  Created by MJ Lee on 2018/5/9.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MJPerson.h"
#import "MJPerson+Test.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        MJPerson *person = [[MJPerson alloc] init];
        person.age = 10;
        person.weight = 40;
        person.name = @"haha";
        
        MJPerson *person2 = [[MJPerson alloc] init];
        person2.age = 20; // 20是存储在peron2对象内部
        person2.weight = 50; // 50是存放在全局的字典对象里面
        person2.name = @"XJC"; // XJC是存放在全局的字典对象里面
        
        //使用字典这样实现会有三个问题
        /*
         1.字典一直在内存中,内存泄漏问题
         2.不同的对象可能会在不同的线程同时访问这个字典,线程安全问题
         3.比较麻烦
         */
        
        NSLog(@"person - age is %d, weight is %d ,name is %@", person.age, person.weight,person.name);
        NSLog(@"person2 - age is %d, weight is %d ,name is %@", person2.age, person2.weight,person2.name);
    }
    return 0;
}
