//
//  MJPerson+Test.m
//  Interview01-Category的成员变量
//
//  Created by MJ Lee on 2018/5/9.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "MJPerson+Test.h"

//把当前对象的指针当做key
#define MJKey [NSString stringWithFormat:@"%p", self]

@implementation MJPerson (Test)

NSMutableDictionary *names_;
NSMutableDictionary *weights_;
+ (void)load
{
    weights_ = [NSMutableDictionary dictionary];
    names_ = [NSMutableDictionary dictionary];
}

- (void)setName:(NSString *)name
{
    names_[MJKey] = name;
}

- (NSString *)name
{
    return names_[MJKey];
}

- (void)setWeight:(int)weight
{
    weights_[MJKey] = @(weight);
}

- (int)weight
{
    return [weights_[MJKey] intValue];
}
//使用字典这样实现会有三个问题
/*
    1.字典一直在内存中,内存泄漏问题
    2.不同的对象可能会在不同的线程同时访问这个字典,线程安全问题
    3.比较麻烦
 */

//不能使用全局变量,使用全局变量所有的person对象使用的都是一个weight值了
//
//int weight_;
//
//- (void)setWeight:(int)weight
//{
//    weight_ = weight;
//}
//
//- (int)weight
//{
//    return weight_;
//}

@end
