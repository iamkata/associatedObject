//
//  MJPerson+Test.m
//  Interview01-Category的成员变量
//
//  Created by MJ Lee on 2018/5/9.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "MJPerson+Test.h"
#import <objc/runtime.h>

@implementation MJPerson (Test)

#pragma mark - key推荐写法
//原来Person实例对象存的东西是
//{
//    Class isa;
//    int _age;
//};

//使用关联对象技术不会改变原来实例对象和类对象的结构

//推荐这个:易懂,可读性高
- (void)setName:(NSString *)name
{
    //OBJC_ASSOCIATION_COPY_NONATOMIC ==  nonatomic + copy
    //将self和name关联起来
    objc_setAssociatedObject(self, @selector(name), name, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (NSString *)name
{
    // 隐式参数
    // _cmd == @selector(name)
    return objc_getAssociatedObject(self, _cmd);
}

/*
 _cmd是当前方法的@selector,如果是get方法就是@selector(name),如果是set方法就是@selector(setName),所以说setName方法里面不能换成_cmd
 
 - (NSString *)name:(id)self _cmd:(SEL)_cmd
 {
 // 隐式参数
 // _cmd == @selector(name)
 return objc_getAssociatedObject(self, _cmd);
 }
 */

- (void)setWeight:(int)weight
{
    //OBJC_ASSOCIATION_RETAIN_NONATOMIC == nonatomic + strong
    objc_setAssociatedObject(self, @selector(weight), @(weight), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (int)weight
{
    // _cmd == @selector(weight)
    //return [objc_getAssociatedObject(self, @selector(weight)) intValue];
    return [objc_getAssociatedObject(self, _cmd) intValue];
}

#pragma mark - key其他写法

/*
 key的第一种用法
 static const void *MJNameKey = &MJNameKey;
 static const void *MJWeightKey = &MJWeightKey;
 - (void)setName:(NSString *)name
 {
 objc_setAssociatedObject(self, MJNameKey, name, OBJC_ASSOCIATION_COPY_NONATOMIC);
 }
 
 - (NSString *)name
 {
 return objc_getAssociatedObject(self, MJNameKey);
 }
 
 - (void)setWeight:(int)weight
 {
 objc_setAssociatedObject(self, MJWeightKey, @(weight), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
 }
 
 - (int)weight
 {
 return [objc_getAssociatedObject(self, MJWeightKey) intValue];
 }
 */

/*
 key的第二种用法
 只是为了传进去一个地址,所以用只占一个字节的char,更省事,而且没必要赋值,因为我们只用地址
 static const char MJNameKey;
 static const char MJWeightKey;
 - (void)setName:(NSString *)name
 {
 objc_setAssociatedObject(self, &MJNameKey, name, OBJC_ASSOCIATION_COPY_NONATOMIC);
 }
 
 - (NSString *)name
 {
 return objc_getAssociatedObject(self, &MJNameKey);
 }
 
 - (void)setWeight:(int)weight
 {
 objc_setAssociatedObject(self, &MJWeightKey, @(weight), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
 }
 
 - (int)weight
 {
 return [objc_getAssociatedObject(self, &MJWeightKey) intValue];
 }
 */

/*
 key的第三种用法
 //NSString *str = @"name";   传进去@"name"和传进去str都是一个意思,都是地址值
 #define MJNameKey @"name"
 #define MJWeightKey @"weight"
 - (void)setName:(NSString *)name
 {
 objc_setAssociatedObject(self, MJNameKey, name, OBJC_ASSOCIATION_COPY_NONATOMIC);
 }
 
 - (NSString *)name
 {
 return objc_getAssociatedObject(self, MJNameKey);
 }
 
 - (void)setWeight:(int)weight
 {
 objc_setAssociatedObject(self, MJWeightKey, @(weight), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
 }
 
 - (int)weight
 {
 return [objc_getAssociatedObject(self, MJWeightKey) intValue];
 }

 */
@end
